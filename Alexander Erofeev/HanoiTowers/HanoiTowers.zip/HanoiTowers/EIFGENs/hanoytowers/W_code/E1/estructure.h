#ifndef _estructure_h_
#define _estructure_h_

#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif

struct eif_ex_11 {union overhead overhead; char data [1];};
struct eif_ex_22 {union overhead overhead; char data [1];};
struct eif_ex_183 {union overhead overhead; char data [8];};
struct eif_ex_186 {union overhead overhead; char data [8];};
struct eif_ex_189 {union overhead overhead; char data [8];};
struct eif_ex_192 {union overhead overhead; char data [8];};
struct eif_ex_195 {union overhead overhead; char data [8];};
struct eif_ex_198 {union overhead overhead; char data [8];};
struct eif_ex_201 {union overhead overhead; char data [8];};
struct eif_ex_204 {union overhead overhead; char data [8];};
struct eif_ex_207 {union overhead overhead; char data [8];};
struct eif_ex_210 {union overhead overhead; char data [8];};
struct eif_ex_213 {union overhead overhead; char data [8];};
struct eif_ex_216 {union overhead overhead; char data [8];};
struct eif_ex_219 {union overhead overhead; char data [8];};
struct eif_ex_222 {union overhead overhead; char data [8];};
struct eif_ex_254 {union overhead overhead; char data [8];};
struct eif_ex_301 {union overhead overhead; char data [8];};
struct eif_ex_305 {union overhead overhead; char data [8];};
struct eif_ex_309 {union overhead overhead; char data [8];};
struct eif_ex_313 {union overhead overhead; char data [8];};
struct eif_ex_523 {union overhead overhead; char data [8];};
struct eif_ex_545 {union overhead overhead; char data [8];};
struct eif_ex_869 {union overhead overhead; char data [8];};
struct eif_ex_873 {union overhead overhead; char data [8];};
struct eif_ex_878 {union overhead overhead; char data [8];};
struct eif_ex_882 {union overhead overhead; char data [8];};
struct eif_ex_888 {union overhead overhead; char data [8];};
struct eif_ex_892 {union overhead overhead; char data [8];};
struct eif_ex_896 {union overhead overhead; char data [8];};
struct eif_ex_901 {union overhead overhead; char data [8];};

#ifdef __cplusplus
}
#endif
#endif
