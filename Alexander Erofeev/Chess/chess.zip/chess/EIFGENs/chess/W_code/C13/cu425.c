/*
 * Code for class CURSOR_STRUCTURE [REAL_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"


#ifdef __cplusplus
extern "C" {
#endif

extern void EIF_Minit425(void);

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

void EIF_Minit425 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
