/*
 * Code for class EXCEP_CONST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"


#ifdef __cplusplus
extern "C" {
#endif

extern EIF_TYPED_VALUE F21_496(EIF_REFERENCE);
extern EIF_TYPED_VALUE F21_497(EIF_REFERENCE);
extern EIF_TYPED_VALUE F21_498(EIF_REFERENCE);
extern EIF_TYPED_VALUE F21_499(EIF_REFERENCE);
extern EIF_TYPED_VALUE F21_500(EIF_REFERENCE);
extern EIF_TYPED_VALUE F21_501(EIF_REFERENCE);
extern EIF_TYPED_VALUE F21_502(EIF_REFERENCE);
extern EIF_TYPED_VALUE F21_503(EIF_REFERENCE);
extern EIF_TYPED_VALUE F21_504(EIF_REFERENCE);
extern EIF_TYPED_VALUE F21_505(EIF_REFERENCE);
extern EIF_TYPED_VALUE F21_506(EIF_REFERENCE);
extern EIF_TYPED_VALUE F21_507(EIF_REFERENCE);
extern EIF_TYPED_VALUE F21_508(EIF_REFERENCE);
extern EIF_TYPED_VALUE F21_509(EIF_REFERENCE);
extern EIF_TYPED_VALUE F21_510(EIF_REFERENCE);
extern EIF_TYPED_VALUE F21_511(EIF_REFERENCE);
extern EIF_TYPED_VALUE F21_512(EIF_REFERENCE);
extern EIF_TYPED_VALUE F21_513(EIF_REFERENCE);
extern EIF_TYPED_VALUE F21_514(EIF_REFERENCE);
extern EIF_TYPED_VALUE F21_515(EIF_REFERENCE);
extern EIF_TYPED_VALUE F21_516(EIF_REFERENCE);
extern EIF_TYPED_VALUE F21_517(EIF_REFERENCE);
extern EIF_TYPED_VALUE F21_518(EIF_REFERENCE);
extern EIF_TYPED_VALUE F21_519(EIF_REFERENCE);
extern EIF_TYPED_VALUE F21_520(EIF_REFERENCE);
extern EIF_TYPED_VALUE F21_521(EIF_REFERENCE);
extern EIF_TYPED_VALUE F21_522(EIF_REFERENCE);
extern EIF_TYPED_VALUE F21_523(EIF_REFERENCE);
extern EIF_TYPED_VALUE F21_524(EIF_REFERENCE);
extern EIF_TYPED_VALUE F21_525(EIF_REFERENCE);
extern EIF_TYPED_VALUE F21_526(EIF_REFERENCE);
extern EIF_TYPED_VALUE F21_527(EIF_REFERENCE);
extern EIF_TYPED_VALUE F21_528(EIF_REFERENCE, EIF_TYPED_VALUE);
extern void EIF_Minit21(void);

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EXCEP_CONST}.void_call_target */
EIF_TYPED_VALUE F21_496 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	return r;
}

/* {EXCEP_CONST}.no_more_memory */
EIF_TYPED_VALUE F21_497 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	return r;
}

/* {EXCEP_CONST}.precondition */
EIF_TYPED_VALUE F21_498 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	return r;
}

/* {EXCEP_CONST}.postcondition */
EIF_TYPED_VALUE F21_499 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	return r;
}

/* {EXCEP_CONST}.floating_point_exception */
EIF_TYPED_VALUE F21_500 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
	return r;
}

/* {EXCEP_CONST}.class_invariant */
EIF_TYPED_VALUE F21_501 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
	return r;
}

/* {EXCEP_CONST}.check_instruction */
EIF_TYPED_VALUE F21_502 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
	return r;
}

/* {EXCEP_CONST}.routine_failure */
EIF_TYPED_VALUE F21_503 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	return r;
}

/* {EXCEP_CONST}.incorrect_inspect_value */
EIF_TYPED_VALUE F21_504 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 9L);
	return r;
}

/* {EXCEP_CONST}.loop_variant */
EIF_TYPED_VALUE F21_505 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
	return r;
}

/* {EXCEP_CONST}.loop_invariant */
EIF_TYPED_VALUE F21_506 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 11L);
	return r;
}

/* {EXCEP_CONST}.signal_exception */
EIF_TYPED_VALUE F21_507 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 12L);
	return r;
}

/* {EXCEP_CONST}.eiffel_runtime_panic */
EIF_TYPED_VALUE F21_508 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 13L);
	return r;
}

/* {EXCEP_CONST}.rescue_exception */
EIF_TYPED_VALUE F21_509 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 14L);
	return r;
}

/* {EXCEP_CONST}.out_of_memory */
EIF_TYPED_VALUE F21_510 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 15L);
	return r;
}

/* {EXCEP_CONST}.resumption_failed */
EIF_TYPED_VALUE F21_511 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16L);
	return r;
}

/* {EXCEP_CONST}.create_on_deferred */
EIF_TYPED_VALUE F21_512 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 17L);
	return r;
}

/* {EXCEP_CONST}.external_exception */
EIF_TYPED_VALUE F21_513 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 18L);
	return r;
}

/* {EXCEP_CONST}.void_assigned_to_expanded */
EIF_TYPED_VALUE F21_514 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 19L);
	return r;
}

/* {EXCEP_CONST}.exception_in_signal_handler */
EIF_TYPED_VALUE F21_515 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 20L);
	return r;
}

/* {EXCEP_CONST}.io_exception */
EIF_TYPED_VALUE F21_516 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 21L);
	return r;
}

/* {EXCEP_CONST}.operating_system_exception */
EIF_TYPED_VALUE F21_517 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 22L);
	return r;
}

/* {EXCEP_CONST}.retrieve_exception */
EIF_TYPED_VALUE F21_518 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 23L);
	return r;
}

/* {EXCEP_CONST}.developer_exception */
EIF_TYPED_VALUE F21_519 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 24L);
	return r;
}

/* {EXCEP_CONST}.eiffel_runtime_fatal_error */
EIF_TYPED_VALUE F21_520 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 25L);
	return r;
}

/* {EXCEP_CONST}.dollar_applied_to_melted_feature */
EIF_TYPED_VALUE F21_521 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 26L);
	return r;
}

/* {EXCEP_CONST}.runtime_io_exception */
EIF_TYPED_VALUE F21_522 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 27L);
	return r;
}

/* {EXCEP_CONST}.com_exception */
EIF_TYPED_VALUE F21_523 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 28L);
	return r;
}

/* {EXCEP_CONST}.runtime_check_exception */
EIF_TYPED_VALUE F21_524 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 29L);
	return r;
}

/* {EXCEP_CONST}.old_exception */
EIF_TYPED_VALUE F21_525 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 30L);
	return r;
}

/* {EXCEP_CONST}.serialization_exception */
EIF_TYPED_VALUE F21_526 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 31L);
	return r;
}

/* {EXCEP_CONST}.number_of_codes */
EIF_TYPED_VALUE F21_527 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 31L);
	return r;
}

/* {EXCEP_CONST}.valid_code */
EIF_TYPED_VALUE F21_528 (EIF_REFERENCE Current, EIF_TYPED_VALUE arg1x)
{
	GTCX
	char *l_feature_name = "valid_code";
	RTEX;
#define arg1 arg1x.it_i4
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTSN;
	RTDA;
	RTLD;
	
	if ((arg1x.type & SK_HEAD) == SK_REF) arg1x.it_i4 = * (EIF_INTEGER_32 *) arg1x.it_r;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_BOOL, &Result);
	RTLU(SK_INT32,&arg1);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 20, Current, 0, 1, 606);
	RTSA(Dtype(Current));
	RTSC;
	RTME(Dtype(Current), 0);
	RTGC;
	RTDBGEAA(20, Current, 606);
	RTIV(Current, RTAL);
	RTHOOK(1);
	RTDBGAL(Current, 0, 0x04000000, 1,0); /* Result */
	ti4_1 = (((FUNCTION_CAST(EIF_TYPED_VALUE, (EIF_REFERENCE)) RTWF(519, Dtype(Current)))(Current)).it_i4);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) (arg1 >= ((EIF_INTEGER_32) 1L)) && (EIF_BOOLEAN) (arg1 <= ti4_1));
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(2);
	RTDBGLE;
	RTMD(0);
	RTLE;
	RTLO(3);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_BOOL; r.it_b = Result; return r; }
#undef arg1
}

void EIF_Minit21 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
