/*
 * Code for class INDEXABLE [NATURAL_32, INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"


#ifdef __cplusplus
extern "C" {
#endif

extern void EIF_Minit385(void);

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

void EIF_Minit385 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
