#include "eif_eiffel.h"
#include "eif_rout_obj.h"

#ifdef __cplusplus
extern "C" {
#endif

extern void F143_7051(EIF_REFERENCE, EIF_TYPED_VALUE);

#ifdef __cplusplus
}
#endif
