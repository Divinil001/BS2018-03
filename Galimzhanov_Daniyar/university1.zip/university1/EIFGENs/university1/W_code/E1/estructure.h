#ifndef _estructure_h_
#define _estructure_h_

#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif

struct eif_ex_11 {union overhead overhead; char data [1];};
struct eif_ex_21 {union overhead overhead; char data [1];};
struct eif_ex_187 {union overhead overhead; char data [8];};
struct eif_ex_190 {union overhead overhead; char data [8];};
struct eif_ex_193 {union overhead overhead; char data [8];};
struct eif_ex_196 {union overhead overhead; char data [8];};
struct eif_ex_199 {union overhead overhead; char data [8];};
struct eif_ex_202 {union overhead overhead; char data [8];};
struct eif_ex_205 {union overhead overhead; char data [8];};
struct eif_ex_208 {union overhead overhead; char data [8];};
struct eif_ex_211 {union overhead overhead; char data [8];};
struct eif_ex_214 {union overhead overhead; char data [8];};
struct eif_ex_217 {union overhead overhead; char data [8];};
struct eif_ex_220 {union overhead overhead; char data [8];};
struct eif_ex_223 {union overhead overhead; char data [8];};
struct eif_ex_226 {union overhead overhead; char data [8];};
struct eif_ex_255 {union overhead overhead; char data [8];};
struct eif_ex_457 {union overhead overhead; char data [8];};
struct eif_ex_461 {union overhead overhead; char data [8];};
struct eif_ex_466 {union overhead overhead; char data [8];};
struct eif_ex_860 {union overhead overhead; char data [8];};
struct eif_ex_864 {union overhead overhead; char data [8];};
struct eif_ex_869 {union overhead overhead; char data [8];};
struct eif_ex_873 {union overhead overhead; char data [8];};
struct eif_ex_877 {union overhead overhead; char data [8];};
struct eif_ex_881 {union overhead overhead; char data [8];};
struct eif_ex_885 {union overhead overhead; char data [8];};
struct eif_ex_889 {union overhead overhead; char data [8];};
struct eif_ex_893 {union overhead overhead; char data [8];};
struct eif_ex_898 {union overhead overhead; char data [8];};
struct eif_ex_916 {union overhead overhead; char data [8];};

#ifdef __cplusplus
}
#endif
#endif
