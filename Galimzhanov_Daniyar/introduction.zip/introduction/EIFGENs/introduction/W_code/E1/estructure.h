#ifndef _estructure_h_
#define _estructure_h_

#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif

struct eif_ex_11 {union overhead overhead; char data [1];};
struct eif_ex_21 {union overhead overhead; char data [1];};
struct eif_ex_187 {union overhead overhead; char data [8];};
struct eif_ex_190 {union overhead overhead; char data [8];};
struct eif_ex_193 {union overhead overhead; char data [8];};
struct eif_ex_196 {union overhead overhead; char data [8];};
struct eif_ex_199 {union overhead overhead; char data [8];};
struct eif_ex_202 {union overhead overhead; char data [8];};
struct eif_ex_205 {union overhead overhead; char data [8];};
struct eif_ex_208 {union overhead overhead; char data [8];};
struct eif_ex_211 {union overhead overhead; char data [8];};
struct eif_ex_214 {union overhead overhead; char data [8];};
struct eif_ex_217 {union overhead overhead; char data [8];};
struct eif_ex_220 {union overhead overhead; char data [8];};
struct eif_ex_223 {union overhead overhead; char data [8];};
struct eif_ex_226 {union overhead overhead; char data [8];};
struct eif_ex_245 {union overhead overhead; char data [8];};
struct eif_ex_257 {union overhead overhead; char data [8];};
struct eif_ex_312 {union overhead overhead; char data [8];};
struct eif_ex_515 {union overhead overhead; char data [8];};
struct eif_ex_519 {union overhead overhead; char data [8];};
struct eif_ex_523 {union overhead overhead; char data [8];};
struct eif_ex_527 {union overhead overhead; char data [8];};
struct eif_ex_531 {union overhead overhead; char data [8];};
struct eif_ex_535 {union overhead overhead; char data [8];};
struct eif_ex_543 {union overhead overhead; char data [8];};
struct eif_ex_555 {union overhead overhead; char data [8];};
struct eif_ex_559 {union overhead overhead; char data [8];};
struct eif_ex_565 {union overhead overhead; char data [8];};
struct eif_ex_744 {union overhead overhead; char data [8];};
struct eif_ex_754 {union overhead overhead; char data [8];};

#ifdef __cplusplus
}
#endif
#endif
