#ifndef _estructure_h_
#define _estructure_h_

#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif

struct eif_ex_12 {union overhead overhead; char data [1];};
struct eif_ex_22 {union overhead overhead; char data [1];};
struct eif_ex_187 {union overhead overhead; char data [8];};
struct eif_ex_190 {union overhead overhead; char data [8];};
struct eif_ex_193 {union overhead overhead; char data [8];};
struct eif_ex_196 {union overhead overhead; char data [8];};
struct eif_ex_199 {union overhead overhead; char data [8];};
struct eif_ex_202 {union overhead overhead; char data [8];};
struct eif_ex_205 {union overhead overhead; char data [8];};
struct eif_ex_208 {union overhead overhead; char data [8];};
struct eif_ex_211 {union overhead overhead; char data [8];};
struct eif_ex_214 {union overhead overhead; char data [8];};
struct eif_ex_217 {union overhead overhead; char data [8];};
struct eif_ex_220 {union overhead overhead; char data [8];};
struct eif_ex_223 {union overhead overhead; char data [8];};
struct eif_ex_226 {union overhead overhead; char data [8];};
struct eif_ex_246 {union overhead overhead; char data [8];};
struct eif_ex_253 {union overhead overhead; char data [8];};
struct eif_ex_438 {union overhead overhead; char data [8];};
struct eif_ex_442 {union overhead overhead; char data [8];};
struct eif_ex_446 {union overhead overhead; char data [8];};
struct eif_ex_450 {union overhead overhead; char data [8];};
struct eif_ex_454 {union overhead overhead; char data [8];};
struct eif_ex_457 {union overhead overhead; char data [8];};
struct eif_ex_525 {union overhead overhead; char data [8];};
struct eif_ex_853 {union overhead overhead; char data [8];};
struct eif_ex_865 {union overhead overhead; char data [8];};
struct eif_ex_872 {union overhead overhead; char data [8];};
struct eif_ex_877 {union overhead overhead; char data [8];};
struct eif_ex_881 {union overhead overhead; char data [8];};
struct eif_ex_913 {union overhead overhead; char data [8];};

#ifdef __cplusplus
}
#endif
#endif
