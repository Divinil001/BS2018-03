#ifndef _estructure_h_
#define _estructure_h_

#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif

struct eif_ex_11 {union overhead overhead; char data [1];};
struct eif_ex_21 {union overhead overhead; char data [1];};
struct eif_ex_187 {union overhead overhead; char data [8];};
struct eif_ex_190 {union overhead overhead; char data [8];};
struct eif_ex_193 {union overhead overhead; char data [8];};
struct eif_ex_196 {union overhead overhead; char data [8];};
struct eif_ex_199 {union overhead overhead; char data [8];};
struct eif_ex_202 {union overhead overhead; char data [8];};
struct eif_ex_205 {union overhead overhead; char data [8];};
struct eif_ex_208 {union overhead overhead; char data [8];};
struct eif_ex_211 {union overhead overhead; char data [8];};
struct eif_ex_214 {union overhead overhead; char data [8];};
struct eif_ex_217 {union overhead overhead; char data [8];};
struct eif_ex_220 {union overhead overhead; char data [8];};
struct eif_ex_223 {union overhead overhead; char data [8];};
struct eif_ex_226 {union overhead overhead; char data [8];};
struct eif_ex_245 {union overhead overhead; char data [8];};
struct eif_ex_288 {union overhead overhead; char data [8];};
struct eif_ex_292 {union overhead overhead; char data [8];};
struct eif_ex_295 {union overhead overhead; char data [8];};
struct eif_ex_382 {union overhead overhead; char data [8];};
struct eif_ex_459 {union overhead overhead; char data [8];};
struct eif_ex_464 {union overhead overhead; char data [8];};
struct eif_ex_507 {union overhead overhead; char data [8];};
struct eif_ex_516 {union overhead overhead; char data [8];};
struct eif_ex_557 {union overhead overhead; char data [8];};
struct eif_ex_563 {union overhead overhead; char data [8];};
struct eif_ex_567 {union overhead overhead; char data [8];};
struct eif_ex_572 {union overhead overhead; char data [8];};
struct eif_ex_886 {union overhead overhead; char data [8];};
struct eif_ex_890 {union overhead overhead; char data [8];};

#ifdef __cplusplus
}
#endif
#endif
