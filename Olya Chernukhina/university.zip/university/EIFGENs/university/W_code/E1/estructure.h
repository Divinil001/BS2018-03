#ifndef _estructure_h_
#define _estructure_h_

#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif

struct eif_ex_11 {union overhead overhead; char data [1];};
struct eif_ex_22 {union overhead overhead; char data [1];};
struct eif_ex_187 {union overhead overhead; char data [4];};
struct eif_ex_190 {union overhead overhead; char data [4];};
struct eif_ex_193 {union overhead overhead; char data [4];};
struct eif_ex_196 {union overhead overhead; char data [4];};
struct eif_ex_199 {union overhead overhead; char data [8];};
struct eif_ex_202 {union overhead overhead; char data [4];};
struct eif_ex_205 {union overhead overhead; char data [8];};
struct eif_ex_208 {union overhead overhead; char data [4];};
struct eif_ex_211 {union overhead overhead; char data [4];};
struct eif_ex_214 {union overhead overhead; char data [4];};
struct eif_ex_217 {union overhead overhead; char data [4];};
struct eif_ex_220 {union overhead overhead; char data [4];};
struct eif_ex_223 {union overhead overhead; char data [8];};
struct eif_ex_226 {union overhead overhead; char data [4];};
struct eif_ex_263 {union overhead overhead; char data [4];};
struct eif_ex_328 {union overhead overhead; char data [4];};
struct eif_ex_571 {union overhead overhead; char data [4];};
struct eif_ex_580 {union overhead overhead; char data [4];};
struct eif_ex_584 {union overhead overhead; char data [4];};
struct eif_ex_588 {union overhead overhead; char data [4];};
struct eif_ex_592 {union overhead overhead; char data [4];};
struct eif_ex_596 {union overhead overhead; char data [4];};
struct eif_ex_633 {union overhead overhead; char data [4];};
struct eif_ex_637 {union overhead overhead; char data [4];};
struct eif_ex_642 {union overhead overhead; char data [4];};
struct eif_ex_682 {union overhead overhead; char data [4];};
struct eif_ex_687 {union overhead overhead; char data [4];};
struct eif_ex_692 {union overhead overhead; char data [4];};
struct eif_ex_858 {union overhead overhead; char data [4];};

#ifdef __cplusplus
}
#endif
#endif
