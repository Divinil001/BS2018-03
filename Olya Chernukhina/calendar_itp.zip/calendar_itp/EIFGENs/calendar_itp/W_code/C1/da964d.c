/*
 * Class DATE_TIME_LANGUAGE_CONSTANTS
 */

#include "eif_macros.h"


#ifdef __cplusplus
extern "C" {
#endif

static const EIF_TYPE_INDEX egt_0_964 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX egt_1_964 [] = {246,963,0xFFFF};
static const EIF_TYPE_INDEX egt_2_964 [] = {963,0xFFFF};
static const EIF_TYPE_INDEX egt_3_964 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX egt_4_964 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX egt_5_964 [] = {963,0xFFFF};
static const EIF_TYPE_INDEX egt_6_964 [] = {963,0xFFFF};
static const EIF_TYPE_INDEX egt_7_964 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX egt_8_964 [] = {14,0xFFFF};
static const EIF_TYPE_INDEX egt_9_964 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX egt_10_964 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX egt_11_964 [] = {15,0xFFFF};
static const EIF_TYPE_INDEX egt_12_964 [] = {963,0xFFFF};
static const EIF_TYPE_INDEX egt_13_964 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX egt_14_964 [] = {272,231,0xFFFF};
static const EIF_TYPE_INDEX egt_15_964 [] = {272,231,0xFFFF};
static const EIF_TYPE_INDEX egt_16_964 [] = {272,231,0xFFFF};
static const EIF_TYPE_INDEX egt_17_964 [] = {272,231,0xFFFF};
static const EIF_TYPE_INDEX egt_18_964 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX egt_19_964 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX egt_20_964 [] = {231,0xFFFF};


static const struct desc_info desc_964[] = {
	{EIF_GENERIC(NULL), 0xFFFFFFFF, 0xFFFFFFFF},
	{EIF_GENERIC(egt_0_964), 0, 0xFFFFFFFF},
	{EIF_GENERIC(egt_1_964), 1, 0xFFFFFFFF},
	{EIF_NON_GENERIC(0x0195 /*202*/), 2, 0xFFFFFFFF},
	{EIF_NON_GENERIC(0x0195 /*202*/), 3, 0xFFFFFFFF},
	{EIF_NON_GENERIC(0x0195 /*202*/), 4, 0xFFFFFFFF},
	{EIF_NON_GENERIC(0x0195 /*202*/), 5, 0xFFFFFFFF},
	{EIF_NON_GENERIC(0x0195 /*202*/), 6, 0xFFFFFFFF},
	{EIF_NON_GENERIC(0x0195 /*202*/), 7, 0xFFFFFFFF},
	{EIF_NON_GENERIC(0x0195 /*202*/), 8, 0xFFFFFFFF},
	{EIF_NON_GENERIC(0x0195 /*202*/), 9, 0xFFFFFFFF},
	{EIF_GENERIC(egt_2_964), 10, 0xFFFFFFFF},
	{EIF_GENERIC(NULL), 11, 0xFFFFFFFF},
	{EIF_GENERIC(NULL), 12, 0xFFFFFFFF},
	{EIF_GENERIC(egt_3_964), 13, 0xFFFFFFFF},
	{EIF_GENERIC(egt_4_964), 14, 0xFFFFFFFF},
	{EIF_GENERIC(egt_5_964), 15, 0xFFFFFFFF},
	{EIF_GENERIC(egt_6_964), 16, 0xFFFFFFFF},
	{EIF_GENERIC(egt_7_964), 17, 0xFFFFFFFF},
	{EIF_GENERIC(NULL), 18, 0xFFFFFFFF},
	{EIF_GENERIC(NULL), 19, 0xFFFFFFFF},
	{EIF_GENERIC(egt_8_964), 20, 0xFFFFFFFF},
	{EIF_GENERIC(egt_9_964), 21, 0xFFFFFFFF},
	{EIF_GENERIC(egt_10_964), 22, 0xFFFFFFFF},
	{EIF_GENERIC(NULL), 23, 0xFFFFFFFF},
	{EIF_GENERIC(egt_11_964), 24, 0xFFFFFFFF},
	{EIF_GENERIC(NULL), 25, 0xFFFFFFFF},
	{EIF_GENERIC(NULL), 26, 0xFFFFFFFF},
	{EIF_GENERIC(NULL), 27, 0xFFFFFFFF},
	{EIF_NON_GENERIC(0x0787 /*963*/), 28, 0xFFFFFFFF},
	{EIF_NON_GENERIC(0x01C5 /*226*/), 29, 0xFFFFFFFF},
	{EIF_GENERIC(egt_12_964), 30, 0xFFFFFFFF},
	{EIF_GENERIC(egt_13_964), 0x00, 0xFFFFFFFF},
	{EIF_GENERIC(egt_14_964), 0x00, 0xFFFFFFFF},
	{EIF_GENERIC(egt_15_964), 0x00, 0xFFFFFFFF},
	{EIF_GENERIC(egt_16_964), 0x00, 0xFFFFFFFF},
	{EIF_GENERIC(egt_17_964), 0x00, 0xFFFFFFFF},
	{EIF_GENERIC(egt_18_964), 0x00, 0xFFFFFFFF},
	{EIF_GENERIC(egt_19_964), 0x00, 0xFFFFFFFF},
	{EIF_GENERIC(egt_20_964), 0x00, 0xFFFFFFFF},
};
void Init964(void)
{
	IDSC(desc_964, 0, 963);
	IDSC(desc_964 + 1, 1, 963);
	IDSC(desc_964 + 32, 389, 963);
}


#ifdef __cplusplus
}
#endif
